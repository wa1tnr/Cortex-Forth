// Sun Aug 25 03:10:50 UTC 2019 0.1.9 good-compiler-aa-ff-aa_exp  shred: abn-591

/*

 $ git branch | egrep compile
* good-compiler-aa-ff
  good-compiler-aa-ff-aa_exp

 $ git checkout -b  good-compiler-aa-ff-bb_exp 
Switched to a new branch 'good-compiler-aa-ff-bb_exp'

*/

// Edited very recently to notify of the merge:

// Sun Aug 25 03:03:25 UTC 2019 merged good-compiler-aa-ff-aa_exp back into good-compiler-aa-ff

// Also merged this the other way (merged good-compiler-aa-ff
// into good-compiler-aa-ff-aa_exp, which is the current branch
// for this one commit you are reading, now).

// Next: will (again) merge this one commit back to good-compiler-aa-ff.

// old:
// Thu Aug 22 13:08:32 EDT 2019 0.1.8 good-comp-tstorm-hah  shred: abn-531

// On branch  good-comp-tstorm-hah

// chivatru    baspher     dephide     junafid     visdury
// binafo      tipalote    cinaverat   kivano      fawidnok

// rdump and friends - uninterpreted memory map dumps

// pretty decent hex dump now - the blist word

// Compiles at both the keyboard (interactively)
// and from a file!  Tuesday 13 Aug 03:18z

// Also edits a flashROM resident file, by truncating
// it before writing the new version of it.

// The newly-edited file can (of course) be loaded
// in as a program (or just as a series of things
// to be typed automatically as if a human typed
// them).

// mivwre  pokrak  kinten  privak  - Fri Aug  9 01:29:33 UTC 2019 0.1.8 fload-bb-bb
// tronya  vadrige steyva  fanipi

// Try the tronya, Captain.

// Fri Aug  9 01:29:33 UTC 2019

// Other branches:
/*
  fload-aa
  fload-bb-aa
* fload-bb-bb
  master
  reversed-aa
  reversed-bb
  reversed-cc
  reversed-dd
  reversed-ee
  reversed-ff
  reversed-gg
  srev-gg-aa
  srev-gg-aa-ris-aa
*/

// Note that the present branch came from branch exp-m-gg in
// Steno-Keyboard-Arduino-tnr and was chosen since it already
// has the full vocabulary, including defining words : and ;
// available.
