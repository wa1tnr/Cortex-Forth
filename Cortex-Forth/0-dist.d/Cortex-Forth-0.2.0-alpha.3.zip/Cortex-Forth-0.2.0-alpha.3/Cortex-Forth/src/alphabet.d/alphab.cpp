#include <Arduino.h>

const char * myAlphaCcp = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ_____THIS_IS_A_CONST_CHAR_PTR_string__31_AUG_2019__";
