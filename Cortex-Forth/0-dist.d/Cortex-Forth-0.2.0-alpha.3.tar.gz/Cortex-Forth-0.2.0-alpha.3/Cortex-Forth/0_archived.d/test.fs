: emits 0 do emit loop ;
69 68 67 66 65 5
space space emits space space cr
70 79 69 3 emits cr
