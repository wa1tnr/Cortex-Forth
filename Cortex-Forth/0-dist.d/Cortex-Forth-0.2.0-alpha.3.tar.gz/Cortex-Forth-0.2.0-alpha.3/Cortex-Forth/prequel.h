#define MICROCOM_LINUX
#undef MICROCOM_LINUX

#ifdef MICROCOM_LINUX
    #define ECHO_INPUT
#endif
